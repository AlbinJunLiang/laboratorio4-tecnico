<?php
    //phpinfo();
    require "../src/app/app.php";
