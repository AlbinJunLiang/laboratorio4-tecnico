<?php
namespace App\controllers;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Routing\RouteCollectorProxy;


$app->group('/cliente', function (RouteCollectorProxy $cliente) {

    $cliente->post('', Cliente::class . ':create');
    $cliente->get('/filtro', Cliente::class . ':filtrar'); 
    $cliente->get('/read[/{id}]', Cliente::class . ':read');
    $cliente->put('/{id}', Cliente::class . ':update');
    $cliente->delete('/{id}', Cliente::class . ':delete'); 
});


$app->group('/artefacto', function (RouteCollectorProxy $artefacto) {
    $artefacto->post('', Artefacto::class . ':create');
    $artefacto->get('/filtro', Artefacto::class . ':filtrar');
    $artefacto->get('/read[/{id}]', Artefacto::class . ':read');
    $artefacto->put('/{id}', Artefacto::class . ':update'); 
    $artefacto->delete('/{id}', Artefacto::class . ':delete'); 
});

$app->group('/tecnico', function (RouteCollectorProxy $tecnico) {

    $tecnico->post('', Tecnico::class . ':create');
    $tecnico->get('/filtro', Tecnico::class . ':filtrar'); 
    $tecnico->get('/read[/{id}]', Tecnico::class . ':read');
    $tecnico->put('/{id}', Tecnico::class . ':update');
    $tecnico->delete('/{id}', Tecnico::class . ':delete'); 
});

$app->group('/auth', function(RouteCollectorProxy $auth){
    $auth->post('/iniciar', Auth::class . ':iniciar');
});

$app->group('/curso', function(RouteCollectorProxy $curso){
    $curso->get('/read[/{id}]', Curso::class . ':read');
});